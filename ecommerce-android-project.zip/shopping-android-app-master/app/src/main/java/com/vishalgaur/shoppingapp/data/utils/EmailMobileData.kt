package com.vishalgaur.shoppingapp.data.utils

data class EmailMobileData(
	val emails: ArrayList<String> = ArrayList(),
	val mobiles: ArrayList<String> = ArrayList()
)